/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.fue.entity;
import java.sql.Date;
/**
 *
 * @author adminlab
 */
public class Employee {
    int _id;
    String _Name;
    double _Salary;
    Date _HireDate;

    public Employee()
    {
    }
    public Employee(int _id, String _Name, double _Salary, Date _HireDate) {
        this._id = _id;
        this._Name = _Name;
        this._Salary = _Salary;
        this._HireDate = _HireDate;
    }

    public int getId() {
        return _id;
    }

    public void setId(int _id) {
        this._id = _id;
    }

    public String getName() {
        return _Name;
    }

    public void setName(String _Name) {
        this._Name = _Name;
    }

    public double getSalary() {
        return _Salary;
    }

    public void setSalary(double _Salary) {
        this._Salary = _Salary;
    }

    public Date getHireDate() {
        return _HireDate;
    }

    public void setHireDate(Date _HireDate) {
        this._HireDate = _HireDate;
    }
    
}
