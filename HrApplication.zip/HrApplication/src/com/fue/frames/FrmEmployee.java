/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.fue.frames;

import com.fue.entity.Employee;
import com.fue.util.DBConnections;
import java.awt.Container;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.sql.Statement;

import java.sql.Date;
import java.text.DateFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.time.LocalDate;
import java.util.logging.Level;
import java.util.logging.Logger;

import javax.swing.Action;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JRootPane;
import javax.swing.JTextField;

public class FrmEmployee extends JFrame {

    JLabel lblID = new JLabel("Employee ID ");
    JLabel lblName = new JLabel("Employee Name ");
    JLabel lblSalary = new JLabel("Employee Salary ");
    JLabel lblDate = new JLabel("Employee Hire Date ");

    JTextField txtID = new JTextField();
    JTextField txtName = new JTextField();
    JTextField txtSalary = new JTextField();
    JTextField txtDate = new JTextField();

    JButton btnSave = new JButton("Save");
    JButton btnReset = new JButton("Reset");

    public FrmEmployee() {
        initComponent();
    }

    private void initComponent() {

        ButtonListeners act = new ButtonListeners();
        btnSave.addActionListener(act);
        btnReset.addActionListener(act);

        lblID.setBounds(20, 20, 120, 20);
        lblName.setBounds(20, 50, 120, 20);
        lblSalary.setBounds(20, 80, 120, 20);
        lblDate.setBounds(20, 110, 120, 20);
        txtID.setBounds(150, 20, 50, 20);
        txtName.setBounds(150, 50, 200, 20);
        txtSalary.setBounds(150, 80, 150, 20);
        txtDate.setBounds(150, 110, 100, 20);

        btnSave.setBounds(150, 300, 120, 20);
        btnReset.setBounds(280, 300, 120, 20);

        Container c = this.getContentPane();
        c.setLayout(null);

        c.add(lblID);
        c.add(lblName);
        c.add(lblSalary);
        c.add(lblDate);

        c.add(txtID);
        c.add(txtName);
        c.add(txtSalary);
        c.add(txtDate);
        c.add(btnSave);
        c.add(btnReset);

        this.setTitle("Employee Entry");
        this.setSize(500, 500);
        this.setVisible(true);
    }

    private void saveEmployee() {
//        String startDate = "01-02-2013";
//        SimpleDateFormat sdf1 = new SimpleDateFormat("dd-MM-yyyy");
//
//        java.util.Date date;
//        java.sql.Date sqlStartDate = null;
//        try {
//            date = sdf1.parse(startDate);
//            sqlStartDate = new java.sql.Date(date.getTime());
//        } catch (ParseException ex) {
//            Logger.getLogger(FrmEmployee.class.getName()).log(Level.SEVERE, null, ex);
//        }

        int id = Integer.parseInt(txtID.getText());
        String name = txtName.getText();
        double salary = Double.parseDouble(txtSalary.getText());
       // java.sql.Date sqlDate = new java.sql.Date(utilDate.getTime());
        java.sql.Date hireDate;
        hireDate =new Date(System.currentTimeMillis());

        Employee e = new Employee(id, name, salary, hireDate);
        //insertEmployee(e);
        addEmployee(e);
        System.out.println(e.toString());

        //JOptionPane.showMessageDialog(this, "Save Successefully");
    }

    private void reset() {
        txtID.setText("");
        txtName.setText("");
        txtSalary.setText("");
        txtDate.setText("");
    }

    class ButtonListeners implements ActionListener {

        @Override
        public void actionPerformed(ActionEvent e) {

            if (e.getActionCommand().equals("Save")) {
                saveEmployee();
            } else if (e.getActionCommand().equals("Reset")) {
                reset();
            }

        }

    }

    public void addEmployee(Employee e) {
        DBConnections.insertEmployee(e, DBConnections.getUrlOracle(), "hr", "hr");
    }

    public void insertEmployee(Employee emp) {
        Connection cnn = null;
        Statement s = null;
        // String user="hr",password="hr";        
        String user = "", password = "";
        String sqlStament = "INSERT "
                + "INTO EMPLOYEE(EMPID,EMPNAME,EMPSALARY,EMPDATE)"
                + "  VALUES(" + emp.getId() + ",'" + emp.getName()
                + "'," + emp.getSalary() + ",'" + emp.getHireDate() + "')";
        String url = "jdbc:odbc:Driver={Microsoft Access Driver (*.mdb)};DBQ=F:\\Oracle Java\\Hossam\\computekDb01.mdb";
        //String url="jdbc:oracle:thin:@localhost:1521:ORCL" ;        
        try {
            cnn = DriverManager.getConnection(url, user, password);
            s = cnn.createStatement();

            s.execute(sqlStament);
            cnn.close();

        } catch (SQLException e) {

            e.printStackTrace();
        }
    }
}
