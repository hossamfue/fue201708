/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.fue.frames;

import com.fue.entity.Employee;
import com.fue.util.DBConnections;
import java.awt.BorderLayout;
import java.awt.Container;

import java.awt.FlowLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;

import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTable;
import javax.swing.table.DefaultTableModel;

public class FrmEmployeesData extends JFrame {

    DefaultTableModel model = new DefaultTableModel();
    JTable tblEmployee = new JTable(model);
    JScrollPane scrlTblEmployee=new JScrollPane(tblEmployee);
    
    JButton btnLoad = new JButton("Retrive Employees");
    JButton btnAdd = new JButton("Add Employee");

    JPanel pnlMain = new JPanel();
    JPanel pnlButtons = new JPanel();

    public void getEmployeeData() {
        while (model.getRowCount() > 0) {
            model.removeRow(0);
        }
        Connection cnn = null;
        Statement s = null;
        ResultSet rs = null;
        String user = "hr", password = "hr";
        //String user = "", password = "";
        String sqlStament = "SELECT EMPLOYEE_ID,FIRST_NAME ||' ' || LAST_NAME FullName,SALARY,HIRE_DATE\n"
                + " FROM HR.EMPLOYEES";
        //String url = "jdbc:odbc:Driver={Microsoft Access Driver (*.mdb)};DBQ=F:\\Oracle Java\\Hossam\\computekDb01.mdb";
        String url = "jdbc:oracle:thin:@localhost:1521:XE";
        try {
            cnn = DriverManager.getConnection(url, user, password);
            s = cnn.createStatement();
            rs = s.executeQuery(sqlStament);
            int empId = 0;
            String name = "";
            double salary = 0;
            String date = "";
            while (rs.next()) {
                empId = rs.getInt(1);
                name = rs.getString(2);
                salary = rs.getDouble(3);
                date = rs.getString(4);
                System.out.println("Employee ID : " + empId
                        + "\tName : " + name
                        + "\tSalar : " + salary
                        + "\tHire Date : " + date);

                Object[] obj = {empId, name, salary, date};
                model.addRow(obj);
            }

            rs.close();
            cnn.close();

        } catch (SQLException e) {

            e.printStackTrace();
        }
    }

    public FrmEmployeesData() {
        initComponent();

    }

    private void initComponent() {

        setUpModel();
        MyButtonListeners act = new MyButtonListeners();
        btnAdd.addActionListener(act);
        btnLoad.addActionListener(act);
        pnlMain.setLayout(new BorderLayout());
        pnlMain.add(tblEmployee.getTableHeader(), BorderLayout.PAGE_START);
        pnlMain.add(scrlTblEmployee, BorderLayout.CENTER);
        //pnlMain.add(btnLoad,BorderLayout.PAGE_END);

        pnlButtons.add(btnLoad);
        pnlButtons.add(btnAdd);
        pnlButtons.setLayout(new FlowLayout());

        Container c = this.getContentPane();

        c.setLayout(new BorderLayout());
        c.add(pnlMain, BorderLayout.CENTER);
        c.add(pnlButtons, BorderLayout.PAGE_END);

        this.setTitle("Employees Data");
        this.setDefaultCloseOperation(EXIT_ON_CLOSE);
        this.setSize(500, 500);
        this.setVisible(true);

    }

    private void setUpModel() {
        model.addColumn("ID");
        model.addColumn("Name");
        model.addColumn("Salary");
        model.addColumn("Date");
    }

    class MyButtonListeners implements ActionListener {

        @Override
        public void actionPerformed(ActionEvent e) {
            if (e.getActionCommand().equals("Add Employee")) {
                addEmployee();
            } else if (e.getActionCommand().equals("Retrive Employees")) //getEmployeeData();
            {
                getEmployees();
            }
        }

        private void getEmployees() {
            while (model.getRowCount() > 0) {
                model.removeRow(0);
            }
            ArrayList<Employee> employees = (ArrayList<Employee>) DBConnections.retriveEmployees(DBConnections.getUrlOracle(), "hr", "hr");
            for (Employee employee : employees) {
                Object[] obj = {employee.getId(),employee.getName(),employee.getSalary(),employee.getHireDate()};
                model.addRow(obj);
            }

        }

    }

    private void addEmployee() {
        FrmEmployee frmAdd=new FrmEmployee();
    }
}
