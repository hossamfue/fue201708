/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.fue.util;

import com.fue.entity.Employee;
import java.sql.Connection;
import java.sql.Date;
import java.sql.Driver;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.Collection;
import javax.swing.JOptionPane;

public class DBConnections {

    public static String odbcDriver = "sun.jdbc.odbc.JdbcOdbcDriver";
    public static String oraclDriver = "oracle.jdbc.driver.OracleDriver";
    public static String mySqlDriver = "com.mysql.jdbc.Driver";
    public static String mSSQLDriver = "com.microsoft.sqlserver.jdbc.SQLServerDriver";

    public static String urlOracle = "jdbc:oracle:thin:@localhost:1521:XE";
    public static String urlAccessDB = "jdbc:odbc:Driver={Microsoft Access Driver (*.mdb)};DBQ=";

    public static String urlMySql = "jdbc:mysql://localhost/test";//jdbc:mysql://hostname:portNumber/databaseName
    public static String urlMSSQL = "jdbc:sqlserver://localhost;integratedSecurity=true;databasename=Library";
    public static String urlMSSQLR2 = "jdbc:sqlserver://hostname:portNumber;databaseName=dataBaseName";

    public static Collection<Employee> retriveEmployees(String urlDb, String user, String password) {

        ArrayList<Employee> employees = new ArrayList<Employee>();
        try {
            Connection cnn = null;
            Statement s = null;
            ResultSet rs = null;
            String sqlStatement = "SELECT EMPLOYEE_ID, FullName,SALARY,HIRE_DATE\n"
                    + " FROM HREMPLOYEES";
            //System.out.println(sqlStatement);
            cnn = DriverManager.getConnection(urlDb, user, password);
            if (cnn == null) {
                System.out.println("Connection Failed.");
            } else {
                s = cnn.createStatement();
                rs = s.executeQuery(sqlStatement);

                int emp_Id;
                String emp_Name;
                double emp_Salary;
                Date emp_HireDate;
                while (rs.next()) {
                    emp_Id = rs.getInt(1);
                    emp_Name = rs.getString(2);
                    emp_Salary = rs.getDouble("SALARY");
                    emp_HireDate = rs.getDate("HIRE_DATE");
                    employees.add(new Employee(emp_Id, emp_Name, emp_Salary, emp_HireDate));
                    System.out.println("Employee ID :" + emp_Id
                            + " Employee Name :" + emp_Name
                            + " Salary :" + emp_Salary
                            + " Hire Date : " + emp_HireDate);
                }

                rs.close();
                cnn.close();
            }

        } catch (SQLException e) {

            System.out.println(e.getMessage());
            e.printStackTrace();
        }
        return employees;
    }

    public static ResultSet executeSelect(String urlDb, String user, String password, String sqlStatement) {

        Connection conn = null;
        Statement s = null;
        ResultSet rs = null;
        try {
            conn = DriverManager.getConnection(urlDb, user, password);
            if (conn == null) {
                System.out.println("Connection Failed.");
            } else {
                s = conn.createStatement();
                rs = s.executeQuery(sqlStatement);

            }

            //   rs.close();
            // conn.close();               
        } catch (SQLException e) {

            System.out.println(e.getMessage());
            e.printStackTrace();
        }
        return rs;
    }
    public static Connection conn = null;

    public static void insertEmployee(Employee e, String urlDb, String user, String password) {
        try {
            Connection cnn = null;
            Statement s = null;

            String sqlStatement = "INSERT INTO hremployees (\n"
                    + "    employee_id,\n"
                    + "    fullname,\n"
                    + "    salary "
                    + ") VALUES (\n"
                    + "    "+e.getId()+",\n"
                    + "    \'"+e.getName()+"\',\n"
                    + "    "+e.getSalary()
                    + ")";
            
            System.out.println(sqlStatement);
            cnn = DriverManager.getConnection(urlDb, user, password);
            if (cnn == null) {
                System.out.println("Connection Failed.");
            } else {
                s = cnn.createStatement();

                s.execute(sqlStatement);
                JOptionPane.showMessageDialog(null,e.getName()+"Employee Saved Successfully");
                cnn.close();
            }

        } catch (SQLException ex) {

            System.out.println(ex.getMessage());
            ex.printStackTrace();
        }
    }

    public static void insertEmployee(String urlDb, String user, String password) {
        try {
            Connection cnn = null;
            Statement s = null;

            String sqlStatement = "INSERT "
                    + "INTO EMPLOYEE "
                    + "  ( "
                    + "    EMPID, "
                    + "    EMPNAME, "
                    + "    EMPSALARY, "
                    + "    EMPDATE "
                    + "  ) "
                    + "  VALUES "
                    + "  ( "
                    + "    103, "
                    + "    'Hamza', "
                    + "    10000, "
                    + "    '17-JUN-03' "
                    + "  )";
            cnn = DriverManager.getConnection(urlDb, user, password);
            if (cnn == null) {
                System.out.println("Connection Failed.");
            } else {
                s = cnn.createStatement();

                s.execute(sqlStatement);

                cnn.close();
            }

        } catch (SQLException e) {

            System.out.println(e.getMessage());
            e.printStackTrace();
        }
    }

    public static void executeSQL(String urlDb, String user, String password) {
        try {
            Connection cnn = null;
            Statement s = null;
            ResultSet rs = null;
            String sqlStatement
                    = "SELECT EMPLOYEE.EMPID,"
                    + "  EMPLOYEE.EMPNAME,"
                    + "  EMPLOYEE.EMPSALARY,"
                    + "  EMPLOYEE.EMPDATE "
                    + "   FROM EMPLOYEE";

            cnn = DriverManager.getConnection(urlDb, user, password);
            if (cnn == null) {
                System.out.println("Connection Failed.");
            } else {
                s = cnn.createStatement();
                rs = s.executeQuery(sqlStatement);

                int emp_Id;
                String emp_Name;
                double emp_Salary;
                Date emp_HireDate;
                while (rs.next()) {
                    emp_Id = rs.getInt(1);
                    emp_Name = rs.getString("EMPNAME");
                    emp_Salary = rs.getDouble("EMPSALARY");
                    emp_HireDate = rs.getDate("EMPDATE");

                    System.out.println("Employee ID :" + emp_Id
                            + " Employee Name :" + emp_Name
                            + " Salary :" + emp_Salary
                            + " Hire Date : " + emp_HireDate);
                }

                rs.close();
                cnn.close();
            }

        } catch (SQLException e) {

            System.out.println(e.getMessage());
            e.printStackTrace();
        }
    }

    public static void testConnection(String urlDb, String user, String password) {
        try {
            Connection cnn = null;
            System.out.println("=======Start Connect To Database =============");
            cnn = DriverManager.getConnection(urlDb, user, password);
            System.out.println("=======Connected Successefully ==============");
            cnn.close();
        } catch (SQLException e) {

            System.out.println(e.getMessage());
            e.printStackTrace();
        }
    }

    public static void testDriver(String Driver) {

        try {
            System.out.println("=======Driver Start Register =============");
            Class.forName(Driver);
            System.out.println("=======Driver Register Successefully ====");
        } catch (ClassNotFoundException e) {
            System.out.println(e.getMessage());
            e.printStackTrace();
        }

    }

    public static void setUrlOracle(String hostName, String port, String DBName) {
        DBConnections.urlOracle = "jdbc:oracle:thin:@" + hostName + ":" + port + ":" + DBName;
    }

    public static String getUrlOracle() {
        return urlOracle;
    }

    public void setConn(Connection cnn) {
        this.conn = cnn;
    }

    public Connection getConn() {
        return conn;
    }
}
